
#include <stdio.h>

int main(void) {
	// Nacita sa 5 celych cisiel, vykonna sa vyraz a vypise vysledok	

	int a, b, c, d, e;

	scanf("%d %d %d %d %d", &a, &b, &c, &d, &e);
	
	// najprv sa vykonna inkrementacia a dekrementacia potom delenie a nasobenie

	printf("Vysledok vyrazu: %d\n", (e / --a * b++ / c++));
	
	// Vratime a, b, c do stavu pred inkrementaciou/dekrementaciou pre spravny vysledok v dalsom vyraze

	b--;
	c--;
	++a;
	
	// Vykonna sa vyraz a vypise vysledok
	
	// najprv delenie potom sucet a nakoniec pridelenia a modulo

	printf("Vysledok vyrazu: %d\n", (a %= b = d = 1 + e / 2));

	return 0;
}
