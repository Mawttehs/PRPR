
#include <stdio.h>

int main(void) {
	// Nacita cm a kg zo vstupu, convertuje cm na m a vypocita a vypise BMI na 3 desatine miesta

	double m, cm, kg;

	scanf("%lf %lf", &cm, &kg);
		
	m = cm / 100; 

	double bmi = kg / (m*m);

	printf("BMI: %.3lf\n", bmi);
	
	return 0;
}
