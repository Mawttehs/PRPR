
#include <stdio.h>

int main(void) {
	// Nacita 2 cele cisla (operandy) a operator (+, -, *, /), vykonna operaciu na operandoch a vysledok sa vypise 

	int c1, c2;
	char op;
	
	scanf("%d %d %c", &c1, &c2, &op);
	
	if (op == '+') printf("%d + %d = %d\n", c1, c2, (c1+c2));
	else if (op == '-') printf("%d - %d = %d\n", c1, c2, (c1-c2));
	else if (op == '/') printf("%d / %d = %d\n", c1, c2, (c1/c2));
	else if (op == '*') printf("%d * %d = %d\n", c1, c2, (c1*c2));

	return 0;
}
