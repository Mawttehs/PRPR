
#include <stdio.h>

int main(void) {
	/* Nacita 2 cele cisla (operandy) a operator (+, -, *, /) 
	 * Vykonna operaciu na operandoch a vysledok sa vypise 
	 * Pokial bol zadany neznami operator vykonna sa defaultni pripad */

	int c1, c2;
	char op;

	scanf("%d %d %c", &c1, &c2, &op);
	
	switch(op) {
		case '+': printf("%d + %d = %d\n", c1, c2, (c1+c2)); break;
		case '-': printf("%d - %d = %d\n", c1, c2, (c1-c2)); break;
		case '/': printf("%d / %d = %d\n", c1, c2, (c1/c2)); break;
		case '*': printf("%d * %d = %d\n", c1, c2, (c1*c2)); break;
		default: printf("Zle zadana volba\n");
	}

	return 0;
}
