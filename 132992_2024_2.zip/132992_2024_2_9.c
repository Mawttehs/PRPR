
#include <stdio.h>

int main(void) {
	int cisla[11];
	int vstup;
	
	// Nacita 11 cisiel zo vstupu a ulozi ich do pola

	for (int i = 0; i < 11; i++) {
		scanf("%d", &vstup);

		cisla[i] = vstup;
	}
	
	// Skontorluje ci prve zadane cislo je v rozsahu <0, 10>

	if ((cisla[0] < 0 || cisla[0] > 10)) {
			printf("Postupnost je nespravna\n");
			return 0;
	}
	
	// Skontroluje 10 zostavajucih cisiel 

	for (int j = 1; j < 11; j++) {
		if (cisla[j] > (cisla[j-1]*cisla[j-1]) || cisla[j] < (cisla[j-1]/2)) {
			printf("Postupnost je nespravna\n");
			
			return 0;
		}
	}
	
	printf("Postupnost je spravna\n");

	return 0;

}
