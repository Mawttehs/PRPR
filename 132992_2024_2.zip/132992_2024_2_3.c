
#include <stdio.h>

int main(void) {
	// Nacita realne cislo, vypise cislo po precastovani na int a po zaokruhleni

	double cislo;	
	
	scanf("%lf", &cislo);
	
	printf("%d %.0lf\n", (int)cislo, cislo);

	return 0;
}
