
#include <stdio.h>

int main(void) {
	
	// Nacita 3 realne cisla zo vstupu a vypocita a vypise ich priemer

	double x, y, z;

	scanf("%lf %lf %lf", &x, &y, &z);
	
	double p = (x+y+z) / 3.0;

	printf("Priemer cisiel %g %g %g je: %g\n", x, y, z, p);

	return 0;
}

