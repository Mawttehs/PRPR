
#include <stdio.h>

int main(void) {
	
	int n;

	scanf("%d", &n);
	
	double min;
	double max;
	double vstup;
	
	// Nacita N cisiel zo vstupu, porovna ich aby sa zistilo najmensie a najvecsie zadane cislo

	for (int i = 0; i < n; i++) {
		scanf("%lf", &vstup);
		
		if (i == 0) {
			min = vstup;
			max = vstup;
		}

		if (vstup < min) min = vstup;

		if (vstup > max) max = vstup;
	}

	printf("Minimum: %.2f\n", min);
	printf("Maximum: %.2f\n", max);

	return 0;
}
