
#include <stdio.h>

int main(void) {
	// Nacita 2 characteri zo vstupu, male pismena convertuje na velke, vypise velke pismena a ich decimalnu ASCII hodnotu

	char ch_1, ch_2;

	scanf("%c %c", &ch_1, &ch_2);
	
	ch_1 = 'A' + (ch_1 - 'a');
	ch_2 = 'A' + (ch_2 - 'a');

	printf("%c %d\n", ch_1, ch_1);
	printf("%c %d\n", ch_2, ch_2);
	
	return 0;
}
